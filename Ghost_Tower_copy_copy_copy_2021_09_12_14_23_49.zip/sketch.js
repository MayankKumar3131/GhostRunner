var ghost,ghostImg;
var tower ,towerImg;
var door,doorImg,doorGroup;
var climber,climberImg,climberGroup;



function preload(){
  
  towerImg=loadImage("tower.png");
  doorImg=loadImage("door.png");
  doorGroup=new Group();
  climberImg=loadImage("climber.png");
  climberGroup=new Group();
  ghostImg=loadImage("ghost-standing.png");
  
}



function setup(){
  
  createCanvas(400,600);
  tower=createSprite(200,300);
  tower.addImage("tower",towerImg);
  tower.velocityY=2;
  
  ghost=createSprite(200,200,50,50);
  ghost.addImage("ghost",ghostImg);
  ghost.scale=0.35;
  
  
}



function draw(){
  
  if(tower.y>400){
    tower.y=150;
  }
  
  
  if(keyDown("space")){
    ghost.velocityY=-5;
  }
  
  ghost.velocityY=ghost.velocityY+0.8;
  
  if(keyDown("right")){
    ghost.x=ghost.x+2;
  }
  
  if(keyDown("left")){
    ghost.x=ghost.x-2;
  }
  
  if(climberGroup.isTouching(ghost)){
    ghost.velocityY=0;
  }
  
  
  
  
  spawnDoor();
  
  
  drawSprites();
  
  if(ghost.y>600){
    ghost.destroy();
    background("black");
    doorGroup.destroyEach();
    stroke("red");
    textSize(25);
    text("Game Over",200,300);
  }
  
}

function spawnDoor(){
  
  if(frameCount%240==0){
    door=createSprite(200,-50);
    door.addImage("door",doorImg);
    door.x=Math.round(random(120,400));
    door.velocityY=2;
    door.lifetime=650;
    ghost.depth=door.depth;
    ghost.depth=ghost.depth+1;
    doorGroup.add(door);
    
    climber=createSprite(200,10);
    climber.addImage("climber",climberImg);
    climber.x=door.x;
    climber.velocityY=2;
    climber.lifetime=650;
    climberGroup.add(climber);
    
  }
  
}